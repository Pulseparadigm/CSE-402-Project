import os, math, json, numpy as np, mpmath as mp
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import weerakoon_fernando as wf
plt.rcdefaults()
plt.rcParams.update({'font.family':'serif','font.serif':['DejaVu Serif'],'mathtext.fontset':'dejavuserif',
 'font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'legend.fontsize':6.8,'xtick.labelsize':7,'ytick.labelsize':7,
 'axes.grid':True,'grid.alpha':0.3,'grid.linestyle':':','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
 'lines.linewidth':1.3,'lines.markersize':3.5,'savefig.bbox':'tight','savefig.pad_inches':0.02})
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','figures')+os.sep
import os; os.makedirs(OUT,exist_ok=True)
C={'NM':'#0072B2','VNM':'#D55E00','SVNM':'#009E73','STVNM':'#CC79A7'}
MK={'NM':'o','VNM':'s','SVNM':'^','STVNM':'D'}
LAB={'NM':'Newton (NM)','VNM':'Weerakoon–Fernando (VNM)','SVNM':'Simpson-VNM','STVNM':'Steffensen-VNM'}
LS={'NM':'-','VNM':'-','SVNM':'--','STVNM':'-.'}
TW=7.0; CW=3.33

# ---------- group benchmark in double precision (their code, unchanged) ----------
methods={'NM':lambda f,df,x0: wf.newton_method(f,df,x0),'VNM':lambda f,df,x0: wf.vnm(f,df,x0),
         'SVNM':lambda f,df,x0: wf.simpson_vnm(f,df,x0),'STVNM':lambda f,df,x0: wf.steffensen_vnm(f,x0)}
bench=[]
for tc in wf.TEST_CASES:
    row={'name':tc['name'],'x0':tc['x0'],'runs':{}}
    for m,fn in methods.items():
        root,h,err,nf,ni=fn(tc['f'],tc['df'],tc['x0'])
        coc=wf.compute_coc(err)
        conv = abs(tc['f'](root))<1e-10
        row['runs'][m]=dict(root=root,err=err,nfev=nf,ni=ni,coc=None if (coc!=coc) else float(coc),conv=conv)
    bench.append(row)
json.dump([{**r,'runs':{m:{k:v for k,v in d.items()} for m,d in r['runs'].items()}} for r in bench],open('bench.json','w'),indent=1)

# Fig: convergence
fig,axes=plt.subplots(2,3,figsize=(TW,3.9))
for ax,r in zip(axes.flat,bench):
    for m in methods:
        d=r['runs'][m]; e=[max(v,1e-17) for v in d['err']]
        if not d['conv']: e=e[:30]
        lab=f"{m} ({d['ni']} it)" if d['conv'] else f"{m} (no conv. in 100)"
        ax.semilogy(range(1,len(e)+1),e,LS[m],marker=MK[m],color=C[m],label=lab,mfc='white' if m in('SVNM','STVNM') else C[m])
    ax.set_title(r['name']+f"$,\\ x_0={r['x0']}$")
    ax.set_xlabel('Iteration $k$'); ax.set_ylabel(r'$|x_{k}-x_{k-1}|$')
    ax.xaxis.set_major_locator(MaxNLocator(integer=True)); ax.axhline(1e-15,color='gray',lw=0.7,ls=':')
    ax.legend(loc='lower left',frameon=True,framealpha=0.9,edgecolor='none',handlelength=1.8)
fig.tight_layout(); fig.savefig(OUT+'convergence_comparison.pdf'); plt.close()

# Fig: efficiency (iterations & NFEV)
fig,(a1,a2)=plt.subplots(1,2,figsize=(TW,2.35))
labs=[f"$f_{i+1}$" for i in range(6)]; x=np.arange(6); w=0.2
for a,key,yl,top in [(a1,'ni','Iterations to converge',26),(a2,'nfev','Function evaluations (NFEV)',52)]:
    for j,m in enumerate(methods):
        vals=[r['runs'][m][key] for r in bench]
        bars=a.bar(x+(j-1.5)*w,[min(v,top) for v in vals],w,color=C[m],label=LAB[m],edgecolor='black',lw=0.3,
                   hatch=None if m in ('NM','VNM') else ('////' if m=='SVNM' else '....'))
        for b,v,r in zip(bars,vals,bench):
            conv=r['runs'][m]['conv']; s_=('%d'%v)+('' if conv else '*')
            if v>top:
                a.text(b.get_x()+b.get_width()/2,top-0.5,s_,ha='center',va='top',fontsize=5.5,rotation=90,color='black',fontweight='bold',bbox=dict(boxstyle='square,pad=0.1',fc='white',ec='none'))
            else:
                a.text(b.get_x()+b.get_width()/2,v+0.3,s_,ha='center',va='bottom',fontsize=5.5,rotation=90)
    a.set_xticks(x); a.set_xticklabels(labs); a.set_ylabel(yl)
    a.set_ylim(0,top*1.05); a.grid(axis='x',visible=False)
h,l=a1.get_legend_handles_labels()
fig.legend(h,l,ncol=4,frameon=False,loc='upper center',bbox_to_anchor=(0.5,1.06))
fig.tight_layout(); fig.savefig(OUT+'efficiency_summary.pdf'); plt.close()

# ---------- High-precision COC per iteration ----------
mp.mp.dps=400
HP=[("$f_1$",lambda x:x**3+4*x**2-10,-0.5,1.3),("$f_2$",lambda x:mp.sin(x)**2-x**2+1,1.0,1.4),
    ("$f_3$",lambda x:mp.exp(x)-3*x,0.5,0.6),("$f_4$",lambda x:mp.cos(x)-x,0.5,0.7),
    ("$f_5$",lambda x:x**3-2*x-5,2.0,2.1),("$f_6$",lambda x:mp.log(x)+x-2,1.5,1.5)]
def step(m,f,x):
    d=lambda t: mp.diff(f,t); fx=f(x)
    if fx==0: return x
    if m=='NM': return x-fx/d(x)
    if m=='VNM': y=x-fx/d(x); return x-2*fx/(d(x)+d(y))
    if m=='SVNM': y=x-fx/d(x); z=(x+y)/2; return x-6*fx/(d(x)+4*d(z)+d(y))
    d1=(f(x+fx)-fx)/fx; y=x-fx/d1; fy=f(y); d2=(f(y+fy)-fy)/fy if fy!=0 else d1
    return x-2*fx/(d1+d2)
fig,axes=plt.subplots(2,3,figsize=(TW,3.6))
for ax,(nm,f,x0,g) in zip(axes.flat,HP):
    root=mp.findroot(f,g)
    for m in methods:
        x=mp.mpf(x0); e=[abs(x-root)]
        for i in range(200):
            x=step(m,f,x); ee=abs(x-root); e.append(ee)
            if ee<mp.mpf(10)**-150: break
        cocs=[]
        for k in range(2,len(e)):
            if e[k]>mp.mpf(10)**-150 and e[k-1]>0 and e[k-2]>0 and e[k-1]!=e[k-2]:
                cocs.append(float(mp.log(e[k]/e[k-1])/mp.log(e[k-1]/e[k-2])))
        cocs=cocs[-7:]; ks=list(range(-len(cocs)+1,1))
        ax.plot(ks,cocs,LS[m],marker=MK[m],color=C[m],label=m,mfc='white' if m in('SVNM','STVNM') else C[m])
    for p in (2,3,4): ax.axhline(p,color='gray',lw=0.6,ls=':')
    ax.set_ylim(0,4.6); ax.set_title(nm+f", $x_0={x0}$")
    ax.set_xlabel('Iterations before termination'); ax.set_ylabel('COC $\\rho_k$'); ax.xaxis.set_major_locator(MaxNLocator(integer=True))
axes.flat[0].legend(frameon=True,framealpha=0.9,edgecolor='none',loc='lower right',ncol=2)
fig.tight_layout(); fig.savefig(OUT+'coc_comparison.pdf'); plt.close()

# ---------- Multivariate ----------
import scipy.linalg as la
X0=[1.5,0.5]
rootv,histv,errv,nfv,niv=wf.vnm_system(wf.system_F,wf.system_J,X0)
Xn=np.array(X0,float); histn=[Xn.copy()]
for i in range(20):
    Xn=Xn-la.solve(wf.system_J(Xn),wf.system_F(Xn)); histn.append(Xn.copy())
    if la.norm(histn[-1]-histn[-2])<1e-12: break
mp.mp.dps=300
Fm=lambda X: mp.matrix([X[0]**2+X[1]**2-4, X[0]*X[1]-1]); Jm=lambda X: mp.matrix([[2*X[0],2*X[1]],[X[1],X[0]]])
def msolve(m):
    X=mp.matrix(X0); H=[X]
    for i in range(8):
        FX=Fm(X); JX=Jm(X)
        if m=='NM': X=X-mp.lu_solve(JX,FX)
        else: Y=X-mp.lu_solve(JX,FX); X=X-mp.lu_solve(JX+Jm(Y),2*FX)
        H.append(X)
    return H
R=msolve('NM')[-1]
fig,(a1,a2)=plt.subplots(1,2,figsize=(TW,2.5),gridspec_kw={'width_ratios':[1.15,1]})
xs=np.linspace(0.9,2.3,400); ys=np.linspace(0.2,1.3,400); XX,YY=np.meshgrid(xs,ys)
a1.contour(XX,YY,XX**2+YY**2-4,[0],colors='#555555',linewidths=1.1)
a1.contour(XX,YY,XX*YY-1,[0],colors='#999999',linewidths=1.1,linestyles='--')
hn=np.array(histn); hv=np.array(histv)
a1.plot(hn[:,0],hn[:,1],'-o',color=C['NM'],label=f'NM ({len(histn)-1} it)',ms=4)
a1.plot(hv[:,0],hv[:,1],'-s',color=C['VNM'],label=f'VNM ({niv} it)',ms=4)
a1.plot(*X0,'k*',ms=8,label='$X_0=(1.5,0.5)$'); a1.plot(rootv[0],rootv[1],'P',color='black',ms=6,mfc='yellow',label='$X^*$')
a1.text(2.02,1.02,'$x^2+y^2=4$',fontsize=6.5,color='#444444'); a1.text(1.0,1.12,'$xy=1$',fontsize=6.5,color='#777777')
a1.set_xlabel('$x$'); a1.set_ylabel('$y$'); a1.legend(frameon=False,loc='lower left'); a1.set_title('Phase-plane trajectories')
for m in ('NM','VNM'):
    H=msolve(m); e=[]
    for h in H:
        v=mp.norm(h-R)
        if v<mp.mpf(10)**-195: break
        e.append(float(v))
    a2.semilogy(range(len(e)),e,'-'+MK[m],color=C[m],label=LAB[m])
a2.axhline(1e-15,color='gray',ls=':',lw=0.8); a2.text(5.3,3e-14,'$10^{-15}$',fontsize=6.5,color='gray')
a2.set_xlabel('Iteration $k$'); a2.set_ylabel(r'$\|X_k-X^*\|_2$'); a2.set_ylim(1e-200,10); a2.set_yticks([1e0,1e-40,1e-80,1e-120,1e-160,1e-200]); a2.legend(frameon=False,loc='lower left')
a2.set_title('Error decay (300-digit arithmetic)')
fig.tight_layout(); fig.savefig(OUT+'multivariate_trajectory.pdf'); plt.close()
json.dump(dict(niv=niv,nfv=nfv,cocv=float(wf.compute_coc(errv)),root=list(map(float,rootv)),nin=len(histn)-1),open('multi.json','w'))

# ---------- Quadrature illustration ----------
fp=lambda t: 0.6+0.9*np.exp(0.9*(t-0.2))-0.4   # a convex f'
xn,xs_=0.3,2.2
t=np.linspace(0.1,2.4,300)
fig,axs=plt.subplots(1,3,figsize=(TW,1.75),sharey=True)
titles=['Newton: rectangle','VNM: trapezoid','Simpson-VNM: parabola']
for ax,tt in zip(axs,titles):
    ax.plot(t,fp(t),'k',lw=1.2); tt_=np.linspace(xn,xs_,100)
    ax.fill_between(tt_,0,fp(tt_),color='#dddddd',label='exact $\\int f\'$')
    if tt.startswith('Newton'): ax.fill_between(tt_,0,fp(xn),color=C['NM'],alpha=0.45,hatch='///')
    elif tt.startswith('VNM'): ax.fill_between(tt_,0,fp(xn)+(fp(xs_)-fp(xn))*(tt_-xn)/(xs_-xn),color=C['VNM'],alpha=0.45)
    else:
        xm=(xn+xs_)/2; P=np.polyfit([xn,xm,xs_],[fp(xn),fp(xm),fp(xs_)],2)
        ax.fill_between(tt_,0,np.polyval(P,tt_),color=C['SVNM'],alpha=0.45); ax.plot([xm],[fp(xm)],'ko',ms=3)
        ax.text(xm,-0.28,'$z_n$',ha='center',fontsize=7)
    ax.plot([xn,xs_],[fp(xn),fp(xs_)],'ko',ms=3)
    ax.text(xn,-0.28,'$x_n$',ha='center',fontsize=7); ax.text(xs_,-0.28,'$y_n$',ha='center',fontsize=7)
    ax.set_title(tt); ax.set_xticks([]); ax.set_yticks([]); ax.set_ylim(0,fp(2.4)*1.05); ax.grid(False)
    ax.set_xlim(0.1,2.4)
axs[0].set_ylabel("$f'(t)$")
fig.tight_layout(); fig.savefig(OUT+'quadrature_illustration.pdf'); plt.close()
print('done')
