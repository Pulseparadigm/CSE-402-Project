import mpmath as mp, json
mp.mp.dps=60
P=[
 ("$x^3+4x^2-10$", lambda x:x**3+4*x**2-10, [-0.5,1,2,-0.3]),
 ("$\\sin^2x-x^2+1$", lambda x:mp.sin(x)**2-x**2+1, [1,3]),
 ("$x^2-e^x-3x+2$", lambda x:x*x-mp.exp(x)-3*x+2, [2,3]),
 ("$\\cos x-x$", lambda x:mp.cos(x)-x, [1,1.7,-0.3]),
 ("$(x-1)^3-1$", lambda x:(x-1)**3-1, [3.5,2.5]),
 ("$x^3-10$", lambda x:x**3-10, [1.5]),
 ("$xe^{x^2}-\\sin^2x+3\\cos x+5$", lambda x:x*mp.exp(x*x)-mp.sin(x)**2+3*mp.cos(x)+5, [-2]),
 ("$x^2\\sin^2x+e^{x^2\\cos x+\\sin x}-28$", lambda x:x*x*mp.sin(x)**2+mp.exp(x*x*mp.cos(x)+mp.sin(x))-28, [5]),
 ("$e^{x^2+7x-30}-1$", lambda x:mp.exp(x*x+7*x-30)-1, [3.5,3.25]),
]
def run(f,x0,method,eps,mode,maxit=500):
    df=lambda t: mp.diff(f,t)
    x=mp.mpf(x0); xs=[x]; nfe=0
    for i in range(1,maxit+1):
        fx=f(x); d=df(x); nfe+=2
        y=x-fx/d
        if method=='vnm':
            d2=df(y); nfe+=1; xn=x-2*fx/(d+d2)
        else: xn=y
        xs.append(xn)
        c1=abs(xn-x)<eps; c2=abs(f(xn))<eps
        if (c1 and c2) if mode=='and' else (c1 or c2): return xn,i,nfe,xs
        x=xn
    return x,maxit,nfe,xs
def coc(xs,root):
    e=[abs(v-root) for v in xs]
    e=[v for v in e if v>mp.mpf(10)**-55]
    if len(e)<3: return None
    return float(mp.log(e[-1]/e[-2])/mp.log(e[-2]/e[-3]))
import sys
mode=sys.argv[1]
out=[]
for k,(nm,f,x0s) in enumerate(P):
    for x0 in x0s:
        # reference root
        r_ref,_,_,_=run(f,x0,'nm',mp.mpf(10)**-55,'and')
        res={}
        for m in ('nm','vnm'):
            xr,i,nfe,xs=run(f,x0,m,mp.mpf(10)**-15,mode)
            res[m]=(i,nfe,coc(xs,r_ref))
        out.append(dict(k=k+1,name=nm,x0=x0,nm=res['nm'],vnm=res['vnm'],root=mp.nstr(r_ref,15)))
        print(k+1,x0,res,mp.nstr(r_ref,16))
json.dump(out,open(f'mprep_{mode}.json','w'))
