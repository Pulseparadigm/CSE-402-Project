import mpmath as mp, json
mp.mp.dps=400
T=[("f_1","$x^3+4x^2-10$",lambda x:x**3+4*x**2-10,-0.5),
   ("f_2","$\\sin^2x-x^2+1$",lambda x:mp.sin(x)**2-x**2+1,1.0),
   ("f_3","$e^x-3x$",lambda x:mp.exp(x)-3*x,0.5),
   ("f_4","$\\cos x-x$",lambda x:mp.cos(x)-x,0.5),
   ("f_5","$x^3-2x-5$",lambda x:x**3-2*x-5,2.0),
   ("f_6","$\\ln x+x-2$",lambda x:mp.log(x)+x-2,1.5)]
def step(m,f,x):
    d=lambda t: mp.diff(f,t)
    fx=f(x)
    if m=='NM': return x-fx/d(x)
    if m=='VNM':
        y=x-fx/d(x); return x-2*fx/(d(x)+d(y))
    if m=='SVNM':
        y=x-fx/d(x); z=(x+y)/2; return x-6*fx/(d(x)+4*d(z)+d(y))
    if m=='STVNM':
        if fx==0: return x
        d1=(f(x+fx)-fx)/fx; y=x-fx/d1; fy=f(y); d2=(f(y+fy)-fy)/fy if fy!=0 else d1
        return x-2*fx/(d1+d2)
P={'NM':2,'VNM':3,'SVNM':3,'STVNM':2}
out=[]
for key,name,f,x0 in T:
    root=mp.findroot(f,x0 if key!='f_1' else 1.3)
    d1=mp.diff(f,root,1); C2=mp.diff(f,root,2)/(2*d1); C3=mp.diff(f,root,3)/(6*d1)
    theo={'NM':C2,'VNM':C2**2+C3/2,'SVNM':C2**2,'STVNM':d1*C2/2}
    row={'key':key,'name':name}
    for m in P:
        x=mp.mpf(x0); errs=[abs(x-root)]
        for i in range(200):
            x=step(m,f,x); e=abs(x-root); errs.append(e)
            if e<mp.mpf(10)**-300 or e==0 or i>198: break
        # COC from last three errors above 1e-300
        es=[e for e in errs if e>mp.mpf(10)**-150]
        coc=mp.log(es[-1]/es[-2])/mp.log(es[-2]/es[-3])
        # ratio e_{n+1}/e_n^p using pair where e_n ~ 1e-20..1e-60
        cand=[(errs[i],errs[i+1]) for i in range(len(errs)-1) if mp.mpf(10)**-120<errs[i]<mp.mpf(10)**-8]
        a,b=cand[-1]
        ratio=b/a**P[m]
        row[m]=dict(coc=float(coc),ratio=float(ratio),theo=float(abs(theo[m])),iters=len(errs)-1)
        print(key,m,'COC %.4f'%coc,'ratio %.6g theo %.6g'%(ratio,abs(theo[m])))
    out.append(row)
json.dump(out,open('hp.json','w'),indent=1)
