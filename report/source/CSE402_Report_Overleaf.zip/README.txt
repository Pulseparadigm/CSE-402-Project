CSE 402 Project Report -- Overleaf project
==========================================
1. Overleaf: New Project -> Upload Project -> select this zip. Main file: main.tex (pdfLaTeX, BibTeX).
2. Author and university details are set near the top of main.tex (\author blocks and \University).
3. figures/ holds all plots (vector PDFs). code/ holds the scripts that reproduce every number and figure.
4. Please double-check the entries in references.bib before submission.
